from pathlib import Path
import shutil
for source in ['libraries/libDaisy/build/libdaisy.a', 'libraries/DaisySP/build/libdaisysp.a', 'libraries/DaisySP/DaisySP-LGPL/build/libdaisysp-lgpl.a']:
    shutil.copy2(source, Path('prebuilt') / Path(source).name)
