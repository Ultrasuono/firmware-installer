ULTRASUONO UNSTABLE-MODE — Relinking package

Application commit: 14bb4e0302be62878ea8e27a964e15ea16194288
Toolchain: GNU Arm Embedded Toolchain 10-2020-q4-major, GCC 10.2.1.
Newlib 3.3.0. GNU Make and Python 3 are required; put the toolchain on PATH.

This package contains the library sources actually used, compiled archives,
and application objects without debug information. Ultrasuono application
sources are not included.

Extract the package and open a terminal in that folder.
Run `make` to relink the firmware with the supplied libraries.
To modify or replace the LGPL library, edit libraries/DaisySP/DaisySP-LGPL,
run `make rebuild-libraries`, then run `make` to produce rebuilt.bin.
If you modify a compiled library, update the modified sources' timestamps
or clean that library's objects before rebuilding.
Keep shared structure layouts and APIs compatible with the application
objects, which were compiled against the supplied headers.

See FIRMWARE-TERMS.txt and the licenses in the library folders.
DaisySP-LGPL is licensed under LGPL 2.1. Test relinked firmware on hardware.

DaisySP and application objects use LTO; use the matching GCC 10.2.1 toolchain.
